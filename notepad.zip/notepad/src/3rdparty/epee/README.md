epee -  is a small library of helpers, wrappers, tools and so on, used to make my life easier.
